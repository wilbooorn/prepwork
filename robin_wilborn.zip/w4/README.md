# Week 4: Resume and JavaScript

### Resume Writing: [Prepare your Resume][resume]
- **NOTE**: If you've been conditionally accepted, this project is not yet required
- Make sure you complete this and send it to us before your first day!

### Solo Project: [Learn JavaScript][codecademy]
- Introduction to JavaScript through Codecademy
- Covers syntax, functions, loops, control flow, and data structures
- This shouldn't take more than 10 hours to complete
- You do not need to pay for a subscription or turn anything in to us.
  You should complete the free portion though.

[resume]: resume/README.md
[codecademy]: https://www.codecademy.com/learn/javascript
