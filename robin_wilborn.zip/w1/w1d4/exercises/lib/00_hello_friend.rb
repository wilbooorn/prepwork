class Friend

  def greeting(name = nil)
    name ? "Hello, " + name + "!" : "Hello!"
  end
  
end
